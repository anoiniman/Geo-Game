﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseScript : MonoBehaviour 
{
    public GameObject mouseCourser;
    public Camera mainCamera;

    void Update()
    {
        Vector2 mousePosition = new Vector3(Input.mousePosition.x, Input.mousePosition.y);
        Vector2 worldMousePosition = mainCamera.ScreenToWorldPoint(mousePosition);

        mouseCourser.transform.position = worldMousePosition;
    }
}
