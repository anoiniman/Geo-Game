﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VisualViewTopography : MonoBehaviour 
{
    Topography[] topographicInfo = new Topography[1000];

    public GameObject littleDot;
    public float planetRadius; float planetCenterX, planetCenterY;

    // Distance between two points
    float Distance(float pointX, float pointY, float endX, float endY)
    {
        float result = Mathf.Sqrt(((pointX*pointX) - (endX*endX)) + ((pointY*pointY)-(endY*endY)));
        return result;
    }

    void Start()
    {
        planetCenterX = gameObject.transform.position.x;
        planetCenterY = gameObject.transform.position.y;

        float densityStepX = 0; float densityStepY = -planetRadius;
        for (int i = 0; i < topographicInfo.Length; i++)
        {
            // Start in the left part of the circle (-planetRadius)
            float posX = planetCenterX + (-planetRadius) + densityStepX;
            // And in the middel row (densityStepY = -planetRadius)
            float posY = planetCenterY + planetRadius + densityStepY;

            topographicInfo[i] = new Topography();
            while(true)
            {
                if(Distance(posX,posY,planetCenterX, planetCenterY) <= planetRadius)
                {
                    topographicInfo[i].x = posX;  topographicInfo[i].y = posY;
                    topographicInfo[i].littleDot = littleDot; topographicInfo[i].CreateObject();
                    densityStepX += 0.01f;
                    break;
                }
                else if(Distance(posX, 0, planetCenterX, 0) > planetRadius)
                {
                    densityStepY += 0.01f;
                    break;
                }
                else if (Distance(posX, 0, planetCenterX, 0) < planetRadius)
                {
                    densityStepX += 0.01f;
                    break;
                }
                else
                {
                    Debug.LogError("SHIT - this was not suposed to happen, shit");
                }
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "MouseCourser")
        {
            //Do the identifiying
        }
    }
}
