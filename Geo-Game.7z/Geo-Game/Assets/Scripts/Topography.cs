﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Topography : MonoBehaviour 
{
    public float x, y; int height;
    public GameObject littleDot;

    public void CreateObject()
    {
        Vector3 position = new Vector3(x,y,0.0f);
        Quaternion rotation = new Quaternion();

        Instantiate(littleDot, position, rotation);
    }

    void Randomize()
    {
    }
}
